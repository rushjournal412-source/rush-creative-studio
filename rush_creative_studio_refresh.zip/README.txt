RUSH CREATIVE STUDIO — WEBSITE PACKAGE

PREVIEW
1. Extract this ZIP.
2. Open index.html in Chrome, Edge, or Firefox.
3. This is a local preview on your computer.

PUBLISH TO NETLIFY
1. Open your Netlify site dashboard.
2. Go to Deploys.
3. Drag the extracted website folder (the folder containing index.html) into the manual deploy area.
4. Your existing Netlify site will update after deployment.

IMPORTANT ABOUT THE CMS
The /admin folder is currently a setup note, not an active login dashboard.
A real CMS needs a Git repository and authentication configured for your hosting account.
Do not expect /admin to publish posts until that connection is completed.
The sample journal cards are starter content; edit index.html to change them for now.
